include("Kinetics.jl");
include("Control.jl");
include("Flow.jl");
include("Dilution.jl");
#added to run Adis model
include("BalanceEquations.jl")
include("CoagulationModelFactory.jl")

# ----------------------------------------------------------------------------------- #
# Copyright (c) 2016 Varnerlab
# School of Chemical Engineering Purdue University
# W. Lafayette IN 46907 USA

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights 
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
# copies of the Software, and to permit persons to whom the Software is 
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ----------------------------------------------------------------------------------- #
function MassBalances(t,x,dxdt_vector,data_dictionary)
# ---------------------------------------------------------------------- #
# MassBalances.jl was generated using the Kwatee code generation system.
# Username: rachellecover
# Type: PBPK-JULIA
# Version: 1.0
# Generation timestamp: 03-28-2016 17:09:37
# 
# Arguments: 
# t  - current time 
# x  - state vector 
# dxdt_vector - right hand side vector 
# data_dictionary  - Data dictionary instance (holds model parameters) 
# ---------------------------------------------------------------------- #

# Get data from the data_dictionary - 
S = data_dictionary["STOICHIOMETRIC_MATRIX"];
C = data_dictionary["FLOW_CONNECTIVITY_MATRIX"];
tau_array = data_dictionary["TIME_CONSTANT_ARRAY"];

# Correct nagative x's = throws errors in control even if small - 
idx = find(x->(x<0),x);
x[idx] = 0.0;

# Call the kinetics function - 
(calc_rate_vector) = Kinetics(t,x,data_dictionary);
rate_vector = Float64[]
number_of_compartments = size(C, 1)
number_of_species = 7;
#@show number_of_compartments
#@show size(calc_rate_vector)
#to used Adis Model
for j = 1:number_of_compartments
	ReducedDict = Dict()
	upper_index = number_of_species*j
	lower_index = upper_index-6
	currx = x[lower_index:upper_index]
	if (j ==6)
		#in wound
		ReducedDict = buildCoagulationModelDictionary(1)
	else
		ReducedDict = buildCoagulationModelDictionary(0)
	end
	rate_vector_curr = BalanceEquations(t,currx,ReducedDict)
	#@show rate_vector_curr[3]
	for item in rate_vector_curr
		push!(rate_vector, item)
	end
end


# Call the control function - 
(rate_vector) = Control(t,x,rate_vector,data_dictionary);

# Call the flow function - 
(flow_terms_vector,q_vector) = Flow(t,x,data_dictionary);

# Call the dilution function - 
tmp_dvdt_vector = C*q_vector;
(dilution_terms_vector) = Dilution(t,x,tmp_dvdt_vector,data_dictionary);

# Encode the biochemical balance equations as a matrix vector product - 
tmp_vector = flow_terms_vector + S*rate_vector - dilution_terms_vector;

number_of_states = length(tmp_vector);
for state_index in collect(1:number_of_states)
	dxdt_vector[state_index] = tau_array[state_index]*tmp_vector[state_index];
#	if(abs(dxdt_vector[state_index]<1E-10))
#		dxdt_vector[state_index]=0.0
#	end
end

# Return the volume dvdt terms - 
number_of_compartments = length(tmp_dvdt_vector);
for compartment_index in collect(1:number_of_compartments)
	state_vector_index = (number_of_states)+compartment_index;
	dxdt_vector[state_vector_index] = tmp_dvdt_vector[compartment_index];
end

end
